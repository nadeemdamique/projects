---
layout: post
title:  \( \lambda \)
date:   2022-02-28 02:06:05 +0800
author: Fang Guojian
---
$$ \lambda $$, to me, is a beginning of a new journey. So [here]({{ site.baseurl }}) is the beginning of my homepage.
